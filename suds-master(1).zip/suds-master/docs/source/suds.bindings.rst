suds.bindings package
=====================

Submodules
----------

suds.bindings.binding module
----------------------------

.. automodule:: suds.bindings.binding
    :members:
    :undoc-members:
    :show-inheritance:

suds.bindings.document module
-----------------------------

.. automodule:: suds.bindings.document
    :members:
    :undoc-members:
    :show-inheritance:

suds.bindings.multiref module
-----------------------------

.. automodule:: suds.bindings.multiref
    :members:
    :undoc-members:
    :show-inheritance:

suds.bindings.rpc module
------------------------

.. automodule:: suds.bindings.rpc
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: suds.bindings
    :members:
    :undoc-members:
    :show-inheritance:
