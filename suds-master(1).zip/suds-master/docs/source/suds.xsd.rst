suds.xsd package
================

Submodules
----------

suds.xsd.depsort module
-----------------------

.. automodule:: suds.xsd.depsort
    :members:
    :undoc-members:
    :show-inheritance:

suds.xsd.doctor module
----------------------

.. automodule:: suds.xsd.doctor
    :members:
    :undoc-members:
    :show-inheritance:

suds.xsd.query module
---------------------

.. automodule:: suds.xsd.query
    :members:
    :undoc-members:
    :show-inheritance:

suds.xsd.schema module
----------------------

.. automodule:: suds.xsd.schema
    :members:
    :undoc-members:
    :show-inheritance:

suds.xsd.sxbase module
----------------------

.. automodule:: suds.xsd.sxbase
    :members:
    :undoc-members:
    :show-inheritance:

suds.xsd.sxbasic module
-----------------------

.. automodule:: suds.xsd.sxbasic
    :members:
    :undoc-members:
    :show-inheritance:

suds.xsd.sxbuiltin module
-------------------------

.. automodule:: suds.xsd.sxbuiltin
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: suds.xsd
    :members:
    :undoc-members:
    :show-inheritance:
