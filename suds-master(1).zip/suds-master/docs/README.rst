Suds Documentation
==================

In order to generate the ``suds`` html documentation you need Sphinx v1.8.5

This folder must be in the root of the repository. At this very same level do:

       $ make html

The documentation will be stored in the 'build' folder.      


Licensed under LGPL (see the ``LICENSE.txt`` file included in the distribution)
